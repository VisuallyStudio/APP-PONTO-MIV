
import { useState } from 'react';
import { Button } from "../components/ui/button";

const funcionarios = [
  "Bruno Silva",
  "Joao Guilherme",
  "Henrique Libório",
  "Diogo Portela"
];

const getCurrentTime = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export default function RegistoPonto() {
  const [registos, setRegistos] = useState(
    funcionarios.map(nome => ({
      nome,
      entrada: '',
      inicioAlmoco: '',
      fimAlmoco: '',
      saida: '',
      horas: ''
    }))
  );

  const registar = (nome, tipo) => {
    setRegistos(prev => prev.map(reg => {
      if (reg.nome !== nome) return reg;
      const novo = { ...reg };
      novo[tipo] = getCurrentTime();

      if (novo.entrada && novo.saida) {
        const [h1, m1] = novo.entrada.split(":").map(Number);
        const [h2, m2] = novo.saida.split(":").map(Number);
        let totalMin = (h2 * 60 + m2) - (h1 * 60 + m1);

        if (novo.inicioAlmoco && novo.fimAlmoco) {
          const [ha1, ma1] = novo.inicioAlmoco.split(":"), [ha2, ma2] = novo.fimAlmoco.split(":");
          const almocoMin = (parseInt(ha2) * 60 + parseInt(ma2)) - (parseInt(ha1) * 60 + parseInt(ma1));
          totalMin -= almocoMin;
        }

        const horas = Math.floor(totalMin / 60);
        const minutos = totalMin % 60;
        novo.horas = `${horas}h ${minutos}m`;
      }

      return novo;
    }));
  };

  return (
    <div className="container">
      <h1>Registo de Ponto</h1>
      {registos.map(({ nome, entrada, inicioAlmoco, fimAlmoco, saida, horas }) => (
        <div key={nome} className="card">
          <h2>{nome}</h2>
          <div className="grid">
            <div>Entrada: {entrada}</div>
            <Button onClick={() => registar(nome, 'entrada')}>Entrar</Button>
            <div>Início Almoço: {inicioAlmoco}</div>
            <Button onClick={() => registar(nome, 'inicioAlmoco')}>Almoço</Button>
            <div>Fim Almoço: {fimAlmoco}</div>
            <Button onClick={() => registar(nome, 'fimAlmoco')}>Voltar</Button>
            <div>Saída: {saida}</div>
            <Button onClick={() => registar(nome, 'saida')}>Sair</Button>
            <div className="grid-col-span-2">Horas Trabalhadas: <strong>{horas}</strong></div>
          </div>
        </div>
      ))}
    </div>
  );
}
